/*
 * 작성일 : 2024년 3월 8일
 * 작성자 : 컴퓨터공학부 202195049 조승호
 * 설명 : 첫 번째 자바 프로그램
 */
public class first {
	public static void main(String[] args) {
		System.out.println("안녀하세요.");
		System.out.print("조승호입니다.");
		System.out.println("반갑습니다." + "첫 번째 자바 프로그램입니다.");
	}

}
